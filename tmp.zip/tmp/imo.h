#ifndef IMO_H
#define IMO_H
#include<iostream>
#include "absapp.h"
#include "abscontrol.h"
#include "control/imocontrol.h"


class IMO:public absAPP
{
public:
    IMO();

    virtual absresult& run(string);
    virtual ~IMO();

private:
    absControl* control;
};

REGISTER(IMO);
#endif // IMO_H

absresult& IMO::run(string src){
    this->control->set(src);
    this->control->work();
    return this->control->produce();
}

IMO::IMO()
{
    cout <<"The Object Name is \"IMO\" construced!" << endl;
    this->control = new IMOControl;
}
IMO::~IMO()
{
    cout <<"The Object Name is \"IMO\" destroyed!" << endl;
    if(this->control!=NULL)
        delete this->control;
}
