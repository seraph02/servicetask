#include "imocontrol.h"

IMOControl::IMOControl()
{

}
void IMOControl::set(string){

}
void IMOControl::work(){
    rst.putfile("aa");
    rst.putjson("json");
}
absresult& IMOControl::produce(){
    return rst;
}
