#ifndef IMOCONTROL_H
#define IMOCONTROL_H
#include "abscontrol.h"

class IMOControl:public absControl
{
public:
    IMOControl();
    virtual void set(string);
    virtual void work();
    virtual absresult& produce();
private:
    absresult rst;
};

#endif // IMOCONTROL_H
